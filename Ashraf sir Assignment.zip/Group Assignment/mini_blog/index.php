<?php 
	session_start();
	$pageString=$_SERVER['QUERY_STRING'];
	$pageArray=explode("=",$pageString);
	@$page=$pageArray[1];
		echo @$_SESSION['Msg'];
		echo @$_SESSION['Msg'] = "";
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if(@$_SESSION['logiName'] != ""){
include_once("includes/actions/show_action.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
	require_once("includes/layouts/header.php");
/*+++++++++++++++  HEADER LINKS +++++++++++++++++*/
?>
</head>
<body>
<div id="fb-root"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=287017588031608";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
    <div id="page">
    	        <div id="header">
					<?php 	require_once("includes/layouts/logo.php");
	/*+++++++++++++++++ The Main Header Logo+++++++++++++++++++++++++++*/
					?>
                </div>
                </div>
                <div id="content">
                	<div id="container">
                        <div id="main">
					<?php 	
						require_once("includes/layouts/menu.php");
//+++++++++++++++++++++++ The Main Menu ++++++++++++++++++++++++++++
					?>
				<div id="text">
					<?php 		
					if(@$_SESSION['logiName'] != "")
					require_once("includes/layouts/tab.php");
					if($page == ""){
						if(@$_SESSION['logiName'] != ""){
						require_once("includes/contents/comments_contents.php");
						}else{
						require_once("includes/contents/home_content.php");
						}
					}
					else if($page == "login")
					require_once("includes/contents/login_content.php");
					else if($page == "prof")
					require_once("includes/contents/profile_content.php");
					else if($page == "edit")
					require_once("includes/contents/edit_content.php");
					else if($page == "editorgp")
					require_once("includes/contents/editorgp_content.php");
					else if($page == "frndList")
					require_once("includes/contents/friend_list.php");
					else if($page == "fcbkPage")
					require_once("includes/contents/facebook_content.php");
					else if($page == "myPost")
					require_once("includes/contents/mypost_content.php");
//+++++++++++++++++++++++ The Main Menu ++++++++++++++++++++++++++++
					?>
					</div>
                        </div>
                </div>
                <div class="clear"></div>
					<?php 		require_once("includes/layouts/footer.php");
//+++++++++++++++++++++++ The Main Menu ++++++++++++++++++++++++++++
					?>
     </div>
        
</body>
</html>
