 var frmvalidator = new Validator("reg_form");
 frmvalidator.addValidation("names","req","Please enter your Name");
 frmvalidator.addValidation("names","maxlen=50","Max length 50");
 frmvalidator.addValidation("address","req","Please enter Adress");
 frmvalidator.addValidation("contact","req","Please enter Contact");
 frmvalidator.addValidation("contact","numeric","Intake must be 11 Digit Value");
 frmvalidator.addValidation("contact","minlen=11","Min length 11");
 frmvalidator.addValidation("email","req","Please enter your Email");
 frmvalidator.addValidation("email","maxlen=50","Max length 50");
 frmvalidator.addValidation("blood","req","Please SELECT your Boold Group");
 frmvalidator.addValidation("userName","req","Please enter your User Name");
 frmvalidator.addValidation("userName","maxlen=50","Max length 50");
 frmvalidator.addValidation("pwd","req","Please enter your Password");

var frmvalidator = new Validator("login");
 frmvalidator.addValidation("username","req","Please enter your User Name");
 frmvalidator.addValidation("pass","req","Please enter your Password");
