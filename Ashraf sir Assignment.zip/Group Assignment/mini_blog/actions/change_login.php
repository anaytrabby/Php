<?php
session_start();
	require_once("../con_db.php");
	/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	if($_POST['upDateBtn']=="Change"){
		$usName = $_POST['usName'];
		$prePawd=$_POST['pwdPre'];
		$newPawd=$_POST['pwdNew'];
		$updateSql = "UPDATE tbl_user
					SET ui_pwd = '$newPawd' 
					WHERE ui_name='$usName' AND ui_pwd='$prePawd'";
					
	$updateResultSet = @mysql_query($updateSql) or die("Error in Insertion: ".mysqli_error($con));				

	$selUpLog = "SELECT * FROM tbl_user WHERE ui_name='$usName' AND ui_pwd='$newPawd'";
	$selLogResult = @mysqli_query($con,$selUpLog) or die();			
	$updateResRec = mysqli_num_rows($selLogResult);

				if($updateResRec > 0)
					$_SESSION['Msg'] = "<h2 style='color:#0762bd; font-size: 50px;'>Password Changed Successfully</h2>";
				else
					$_SESSION['Msg'] = "<h2 style='color:#bf0000; font-size: 50px;'>Previous Password Does not match!!</h2>";	
			header('Location: '.BASE.'index.php?page=edit');
	}
?>