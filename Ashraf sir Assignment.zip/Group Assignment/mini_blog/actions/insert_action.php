<?php session_start();
require_once ("../con_db.php");
/*GENERATING ID NO...........*/
$sqlId = "SELECT MAX( cmt_id ) AS newId	FROM tbl_comments";
/*Write Down the SQL for SELCTION
 to get the RECENT ID number*/
$resultSet = @mysqli_query($con,$sqlId);
/*QUERY Execution function*/
$records = @mysqli_fetch_object($resultSet);
/*Get the Original Value from QUERy Integer*/
$_SESSION['newCommentId'] = $records -> newId + 1;
/*Increment the RECORD number As per (ID) number generate*/
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*GENERATING POST ID NO...........*/
$sqlId = "SELECT MAX( spr_post_id ) AS newId	
		FROM tbl_super_post";
$resultSet = @mysqli_query($con,$sqlId);
$records = @mysqli_fetch_object($resultSet);
$_SESSION['newSprPostId'] = $records -> newId + 1;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if (@$_POST['submitBtn'] == "Register") {
	/*PERSONAL INFO*/
	$name = $_POST['name'];
	$address = mysqli_real_escape_string($con,$_POST['address']);
	$contact = $_POST['contact'];
	$email = $_POST['email'];
	$blood = $_POST['blood'];
	$gendr = $_POST['gndr'];
	/*USER INFO*/
	@$_SESSION[userName] = $_POST['usrName'];
	$pwd = md5($_POST['pwd']);
	/*IMAGE INFO*/
	$pic = ($_FILES['photo']['name']);
	/*DUPLICATE DATA INSERTION.................*/
	$chkSql = "SELECT * FROM tbl_registration WHERE ri_email='$email'";
	/*+++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Now Execute the QUERY by Function
	 It Give An (((Integer))) Value for QUERY Result
	 ++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	$chkResultSet = @mysqli_query($con,$chkSql);
	/*+++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Now Form the QUERY (((Integer))) Value
	 Get the Original Value (What we input in Form)
	 by USING fungtion :(mysql_fetch_object)
	 ++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	$chkRecord = @mysqli_num_rows($chkResultSet);
	/*+++++++++++++++++++++++++++++++++
	 Check for Duplicate Record and User Available++++++ >>>
	 +++++++++++++++++++++++++++++++++++*/
	if ($chkRecord > 0) {
		$_SESSION['insertMsg'] = "<h2>Data Inserted Before!</h2>";
		header('Location: ' . BASE . '');
	} else {
		/*GENERATING ID NO...........*/
		$sqlId = "SELECT MAX( ri_id ) AS newId FROM tbl_registration";
		/*Write Down the SQL for SELCTION
		 to get the RECENT ID number*/
		$resultSet = @mysqli_query($con,$sqlId);
		/*QUERY Execution function*/
		$records = @mysqli_fetch_object($resultSet);
		/*Get the Original Value from QUERy Integer*/
		$_SESSION['newInfoId'] = $records -> newId + 1;
		/*Increment the RECORD number As per (ID) number generate*/
		/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 |				Image Upload 							|
		 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
		$target = "../../images/upload/";
		$target = $target . basename($_FILES['photo']['name']);
		//Writes the photo to the server
		move_uploaded_file($_FILES['photo']['tmp_name'], $target);
		/*++++++++++++++++++END of IMAGE Upload++++++++++++++++++++++++++++*/
		/*INSERTION REGISTRATION....................*/
		$insertUser = "0,
						'$_SESSION[userName]',
						   '$pwd',
						   now(),
						   $_SESSION[newInfoId]";
		/*INSERTION REGISTRATION....................*/
		$insertRecord = "$_SESSION[newInfoId],
								'$name','$gendr',
								'$address',
								'$contact',
								'$email',
								'$pic','$blood',1";
		/*++++++++++++++++++Comment Default ...............*/
		$defltCommnt = "INSERT INTO tbl_comments 
				VALUES($_SESSION[newInfoId],0,$_SESSION[newCommentId],0,'Hey," . $_SESSION['userName'] . "! How Are You?',now(),'C')";
		$queryDfltCmmnt = @mysqli_query($con,$defltCommnt) or die("Error in Comments: " . mysqli_error($con));
		/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
		/*++++++++++++++++++++ default SUPER post ++++++++++++++++++++++*/
		$defltPost = "INSERT INTO tbl_super_post VALUES($_SESSION[newInfoId],$_SESSION[newSprPostId],
				'Hey," . $_SESSION['userName'] . "! Take A Tour on Super Post in POST page :)',now())";
		$queryDfltPost = @mysqli_query($con,$defltPost) or die("Error in Comments: " . mysqli_error($con));
		/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

		$insertSql = "INSERT INTO tbl_registration VALUES($insertRecord)";
		$insertUser = "INSERT INTO tbl_user VALUES($insertUser)";
		/*Again QUERY Execution function and PUT the VAlue in a VARIABLE*/
		$insertResultSet = @mysqli_query($con,$insertSql) or die("Error in Insertion: " . mysqli_error($con));
		$insertResultUser = @mysqli_query($con,$insertUser) or die("Error in Insertion User: " . mysqli_error($con));
		if ($insertResultSet)
			$_SESSION['Msg'] = "<h2 style='color:#0762bd; font-size: 50px;'>Your Registration Done Successfully!</h2>";
		else
			$_SESSION['Msg'] = "<h2 style='color:#bf0000; font-size: 50px;'>Something Get Error! </h2>";
		header('Location: ' . BASE . 'index.php?page=login');
	}
}

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 ||					Comments Text Insertion							||
 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (@$_POST['cmmnt'] == "POST") {
	/*PERSONAL INFO*/
	$comment = $_POST['comments'];
	/*++++++++++++++++++++++++++Select Corresponding ID++++++++++++++++++++++++++*/
	$sqlNormal = "SELECT * FROM tbl_user WHERE ui_name='$_SESSION[logiName]'";
	$resultSet = @mysqli_query($con,$sqlNormal) or die('Error in Query Error: ' . mysqli_error($con));
	$commentsObj = @mysqli_fetch_object($resultSet);
	$commentUserId = $commentsObj -> ui_ri;
	/*INSERTION REGISTRATION....................*/
	$insertCommnt = "$commentUserId,'',$_SESSION[newCommentId],'$comment',0,now(),'C'";
	$insertCommnt = "INSERT INTO tbl_comments VALUES($insertCommnt)";
	/*Again QUERY Execution function and PUT the VAlue in a VARIABLE*/
	$insertResultCommnt = @mysqli_query($con,$insertCommnt) or die("Error in Insertion User: " . mysqli_error($con));
	header('Location: ' . BASE . 'index.php');
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 |			Comments REPLY Actions
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
if (@$_POST['replBtn'] == "REPLY") {
	/*PERSONAL INFO*/
	$reply = mysqli_real_escape_string($con,$_POST['replies']);
	$rplyToId = $_POST['rplyToId'];
	$cmtTo = $_POST['cmtTo'];
	/*++++++++++++++++++++++++++Select Corresponding ID++++++++++++++++++++++++++*/
	$sqlReply = "SELECT * FROM tbl_user WHERE ui_name='$_SESSION[logiName]'";
	$qryReply = @mysqli_query($con,$sqlReply) or die('Error in Query Error: ' . mysqli_error($con));
	$replyRecrd = @mysqli_fetch_object($qryReply);
	$replyUserId = $replyRecrd -> ui_ri;
	/*INSERTION REGISTRATION....................*/
	$insertReps = "$replyUserId,$rplyToId,$_SESSION[newCommentId],$cmtTo,'$reply',now(),'R'";
	$insertReps = "INSERT INTO tbl_comments VALUES($insertReps)";
	/*Again QUERY Execution function and PUT the VAlue in a VARIABLE*/
	$insertResultReps= @mysqli_query($con,$insertReps) or die("Error in Insertion Reply: " . mysqli_error($con));
	header('Location: ' . BASE . 'index.php');
}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 |			Super POST by Ck Editor
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (@$_POST['sprPost'] == "POST") {
	/*PERSONAL INFO*/
	$superPost = $_POST['super_post'];
	/*++++++++++++++++++++++++++Select Corresponding ID++++++++++++++++++++++++++*/
	$sqlNormal = "SELECT * FROM tbl_user WHERE 
							ui_name='$_SESSION[logiName]'";
	$resultSet = @mysqli_query($con,$sqlNormal) or die('Error in Query Error: ' . mysqli_error($con));
	$commentsObj = @mysqli_fetch_object($resultSet);
	$commentUserId = $commentsObj -> ui_ri;
	/*INSERTION REGISTRATION....................*/
	$insertSprPost = "$commentUserId,
						$_SESSION[newSprPostId],
						'$superPost',
						   now()";
	$insertSprPost = "INSERT INTO tbl_super_post VALUES($insertSprPost)";
	$insertResultPost = @mysqli_query($con,$insertSprPost) or die("Error in Insertion User: " . mysqli_error($con));
	header('Location: ' . BASE . 'index.php?page=editorgp');
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 |			ADD New Friend ++++++++++++++++++++++++++++++++++
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if ($_POST['addFrnd'] == "ADD") {
	$frndId = $_POST['adFrndId'];
	$frndTime = date("Y-m-d H:i:s");
	$frndAdVAl = "'$_SESSION[uId]','$frndId','$frndTime','A'";
	$sqlFrndAd = "INSERT INTO tbl_friend VALUES($frndAdVAl)";
	$qryFrndAd = @mysqli_query($con,$sqlFrndAd) or die("Error in Insertion User: " . mysqli_error($con));
	header('Location: ' . BASE . 'index.php?page=frndList');
}
?>

