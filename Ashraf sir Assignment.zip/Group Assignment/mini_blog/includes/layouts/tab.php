<br />
<a class="button red" style="text-decoration:none;" href="?page=edit">EDIT</a>
<a class="button red" style="text-decoration:none;" href="?page=frndList">FRIENDS</a>
<br /><br />
