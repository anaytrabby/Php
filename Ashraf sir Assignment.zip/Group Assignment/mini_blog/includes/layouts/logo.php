                	<img src="images/logo.png" alt="A Site By Abrahametry Mii" />
                    <!-- Include an <h1></h1> tag with your site's title here, or make a transparent PNG like the one I used -->
