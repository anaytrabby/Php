<div id="menu">
<ul>
<?php 
if(@$_SESSION['logiName'] != "") {
require_once("includes/actions/show_action.php");	 
?>
<li>
<?php 
echo '<img id="proPic" src="images/upload/'.$aRecord->ri_photos.'" />'; 
?>
</li>
<li><a href="includes/actions/log_out_action.php">Logout|</a></li>
<li><a href="?page=editorgp">All Post |</a></li>
<li><a href="?page=myPost">Submit |</a></li>
<li><a href="?page=prof">Profile |</a></li>
<?php }else{ ?>
<li><a href="?page=login">Login |</a></li> <?php } ?>
<li><a href="index.php">Home |</a></li>
</ul>
</div>