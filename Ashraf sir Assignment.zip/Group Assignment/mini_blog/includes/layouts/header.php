<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/button.css" />
<link rel="stylesheet" type="text/css" href="css/paginate.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/cmt_js.js"></script>
<script type="text/javascript" src="js/validators.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.inview.js"></script>

<!-- ++++++++++ EDITOR LINK ++++++++++ -->
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title>mini POST site</title>
