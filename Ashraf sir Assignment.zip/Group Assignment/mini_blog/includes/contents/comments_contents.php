<strong>As Salamu Alaykum, <?php echo "<em>" . $_SESSION['logiName'] . "</em>"; ?></strong> | Share Your Post here:
<div>
	<table width="100%">
		<form method="post" enctype="multipart/form-data" action="includes/actions/insert_action.php">
		<tr>
			<td>
				<textarea name="comments" cols="35"></textarea> 
			</td>
			<th>
				<input type="submit" name="cmmnt" value="POST" class="button blue" />
			</th>
		</tr>
		</form>
	</table>
</div>
<h4>Now on Online</h4>
<p id="scrollBox">
<?php
if ($numUserCounet > 0) {
	while ($cRecord = mysqli_fetch_object($userCounterSet)) {
		echo '<a class="button" style="color: #0e6655;">' . $cRecord -> ui_name . '</a> ';
	}
} else {
	echo "No User in online";
}
?>
</p>
<br /><hr />
<p>
<h2>Your Comments:</h2>

<?php
if ($numCommentsRecord > 0) { ?>
	<table id="cmntBox" align="center" width="100%">
	<?php while ($bRecord = mysqli_fetch_object($commentsResultSet)) { ?>
		<tr>
			<td><img width="7%" src="images/upload/<?php echo $bRecord -> ri_photos ?>" /> || <?php echo $bRecord -> cmt_text ?> <br />
		<?php if (@$_SESSION['logiName'] != "" && ($bRecord -> cmt_user_id == @$_SESSION['uId'])) { ?>
	<a style="color:#019400;" href="includes/actions/delete_action.php?cmntId=<?php echo $bRecord -> cmt_id ?>&usrId=<?php echo $bRecord -> cmt_user_id ?>">remove</a><?php } ?>
		<em style="color:#bf0000; font-size: 11px">[ <?php 
			$cmntTime = date("l, d M-Y, h:i A",strtotime($bRecord->cmt_time));
			echo $cmntTime;
			?> ]</em><br />
	<?php 
	/*+++++++++++++++++++++++++++ SHOW REPLIES Only Individual +++++++++++++++++++++*/
	$sqlReply = "SELECT * FROM tbl_user,tbl_registration,tbl_comments 
					WHERE (tbl_registration.ri_id = tbl_comments.cmt_user_id AND 
					tbl_user.ui_ri= tbl_registration.ri_id AND cmt_status='R' AND 
					rply_to_id = '$bRecord->cmt_user_id' AND tbl_comments.cmt_to_id=$bRecord->cmt_id)
					GROUP BY cmt_id ORDER BY cmt_time ASC";
	$qryReply = @mysqli_query($con,$sqlReply) or die('Error in Query Error: '.mysqli_error($con));
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	
	while($replyRec = mysqli_fetch_array($qryReply)){	 
		?>	
		<p style="background: #FFFBEA; padding: 2px 5px;"><img width="5%" src="images/upload/<?php echo $replyRec['ri_photos']; ?>" /> <?php echo $replyRec['cmt_text']; ?><br />
		<?php if (@$_SESSION['logiName'] != "" && ($replyRec['cmt_user_id'] == @$_SESSION['uId'])) { ?>
	<a style="color:#019400;" href="includes/actions/delete_action.php?cmntRepId=<?php echo $replyRec['cmt_id'] ?>&replId=<?php echo $replyRec['rply_to_id']; ?>&usrRepId=<?php echo $replyRec['cmt_user_id'] ?>">remove</a><?php } ?>
		<em style="color:#bf0000; font-size: 11px">[ <?php $repTime = date("l, d M-Y, h:i A",strtotime($replyRec['cmt_time']));
			echo $repTime; ?> ]</em><br />
		</p>
	<?php }?>
		<form method="post" enctype="multipart/form-data" action="includes/actions/insert_action.php">
			<input type="hidden" name="rplyToId" value="<?php echo $bRecord -> cmt_user_id; ?>" />
			<input type="hidden" name="cmtTo" value="<?php echo $bRecord -> cmt_id; ?>" />
			<textarea name="replies"></textarea>
			<input type="submit" name="replBtn" value="REPLY" class="button green" />
		</form>
		</td>
		</tr>
	<?php  } ?>
</table>
<?php } else {
	echo "No comment";
	}
?>
	</p>