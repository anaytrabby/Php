<?php
	$host = 'localhost';
	$dbName = 'mini_db';
	$userName = 'root';
	$pwd = '';
	/*Connection*/
$con = @mysqli_connect($host,$userName,$pwd,$dbName);
@define('BASE', 'http://localhost:9090/mini_blog/');
?>