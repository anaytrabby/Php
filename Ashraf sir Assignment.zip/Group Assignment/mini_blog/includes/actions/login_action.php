<?php
	session_start();
	require_once("../con_db.php");	
	if(@$_POST['submit'] == 'Login'){
		$_SESSION['logiName'] = $_POST['username'];
		$loginPwd = md5($_POST['pass']);
		$sql = "SELECT *
				FROM tbl_user
				WHERE ui_name='$_SESSION[logiName]' AND ui_pwd='$loginPwd'";
		$resultSet = mysqli_query($con,$sql) or die('Error Message: '.mysqli_error($con));
		$usrRecs = mysqli_fetch_object($resultSet);
		$_SESSION['uId'] = $usrRecs->ui_ri;
		$count = mysqli_num_rows($resultSet);
		/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
		$updateStatusSql = "UPDATE tbl_user
					SET ui_status = 1 
					WHERE ui_name='$_SESSION[logiName]' AND ui_pwd='$loginPwd'";
					
		$updateStatusSet = @mysqli_query($con,$updateStatusSql) or die("Error in Update: ".mysqli_error($con));
		/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
		if($count > 0){
			$_SESSION['msg'] = "<h2 style='color:#019400; font-size: 50px;'>Login Successf00lly!</h2>";
			header ("Location: ".BASE."index.php?page=prof");
				}
		else{
			$_SESSION['logiName'] = "";
			$loginPwd = "";
			$_SESSION['msg'] = "<h2 style='color:#0762bd; font-size: 50px;'>Username Or Passwrod Wrong</h2>";
			header ("Location: ".BASE."?page=login");
		}
	}
?>
