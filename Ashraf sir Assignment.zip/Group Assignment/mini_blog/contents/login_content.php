<?php 
if(isset($_SESSION['msg'])){
echo $_SESSION['msg'];
echo $_SESSION['msg']= "";
}
if(isset($_SESSION['Msg'])){
 echo @$_SESSION['Msg']; 
 echo $_SESSION['Msg']=""; 
 }
?>
<form id="login" action="includes/actions/login_action.php" method="post" enctype="multipart/form-data" class="login"> 
<table width="100%"> 
	<tr>
		<td>
			<h1>Login</h1>
		</td>
	</tr> 
	<tr>
		<td>
			<label>Username:</label>
			<input id="username" type="text" name="username" maxlength="40"> 
		</td>
	</tr> 
		<tr>
			<td><label>Password:</label>
			<input id="pass" type="password" name="pass" maxlength="50">  
		</td>
	</tr> 
	<tr>
		<td> 
			<input class="button green" type="submit" name="submit" value="Login"> 
		</td>
	</tr> 
</table>
</form>
<!-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
<h1>Please Sign Up! </h1>						 
<form id="reg_form" action="includes/actions/insert_action.php" method="post" enctype="multipart/form-data" name="form1">
<table width="100%" cellpadding="2" cellspacing="2" align="center">
	<tr>
		<td>
		<label><strong>Name:</strong></label>
		</td>
		<td>
		<input id="names" name="name" type="text" />
		</td>
	</tr>
	<tr>
		<td>
		<label><strong>Gender:</strong></label>
		</td>
		<td>
		MALE ♂<input id="gndr" name="gndr" type="radio" value="MALE" />
		FEMALE ♀<input id="gndr" name="gndr" type="radio" value="FEMALE" />
		</td>
	</tr>
	<tr>
		<td>
		<label><strong>Present Adress: </strong></label>
		</td>
		<td>
		<textarea id="address" name="address" cols="20" rows="4" wrap="VIRTUAL"></textarea>
		</td>
	</tr>
	<tr>
	<td>
	<label><strong>Contact No:</strong></label>
	</td>
	<td>
	<input id="contact" name="contact" type="text" />
	</td>
	</tr>
	<tr>
		<td>
			<label><strong>Email:</strong></label>
		</td>
		<td>
			<input id="email" name="email" type="text" maxlength="100">
		</td>
	</tr>
	<tr>
		<td>
			<label><strong>Boold Group:</strong></label>
		</td>
		<td>
			<select name="blood" id="blood">
				<option value="-99">SELECT</option>
				<option value="A+">A+</option>
				<option value="A-">A-</option>
				<option value="AB+">AB+</option>
				<option value="AB-">AB-</option>
				<option value="B+">B+</option>
				<option value="B-">B-</option>
				<option value="O+">O+</option>
				<option value="O-">O-</option>
			</select>
		</td>
	</tr>
	<tr>
		<td>
			<label><strong>Username :</strong></label>
		</td>
		<td>
			<input id="userName" name="usrName" type="text" maxlength="100">
		</td>
	</tr>
	<tr>
		<td>
			<label><strong>Password :</strong></label>
		</td>
		<td>
			<input id="pwd" name="pwd" type="password" maxlength="100">
		</td>
	</tr>
	<tr>
		<td>
			<label for="file"><strong>Photos:</strong></label>
		</td>
		<td>
			<input type="file" name="photo" id="photo" />
		</td>
	</tr>
	<tr>
		<td colspan="2">
		<input class="button blue" type="submit" name="submitBtn" value="Register">
		</td>
	</tr>
</table>	
</form>
<script type="text/javascript" src="js/validation_action.js"></script>
