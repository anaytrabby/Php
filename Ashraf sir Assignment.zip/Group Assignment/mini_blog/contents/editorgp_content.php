<h2>Super Post</h2>
<div>
	<table>
		<form method="post" enctype="multipart/form-data" action="includes/actions/insert_action.php">
		<tr>
			<td>
			<textarea name="super_post"></textarea>
			<script>
				CKEDITOR.replace( 'super_post' );
			</script>
			</td>
		</tr>
		<tr>
			<th>
				<input type="submit" name="sprPost" value="POST" class="google-button google-button-red" />
			</th>
		</tr>
		</form>
	</table>
</div>
<br /><hr />
