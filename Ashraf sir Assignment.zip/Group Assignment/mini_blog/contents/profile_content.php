<?php
if(isset($_SESSION['logiName'])){
 echo $_SESSION['msg']; 
 echo $_SESSION['msg'] = "";
}
if(@$_SESSION['logiName'] != ""){
if($numRecord > 0){
if($_SESSION['logiName'] != ""){
echo '<fieldset>
<legend align="left" style="color:blue;"><h2>MY PROFILE </h2></legend>
<table id="profInfo" width="100%" align="center">
    <tr>
        <th>Mini ID: <strong style="font-size:20px;">'.$aRecord->ri_id.'</strong></th>
        <th colspan="2"><h1>'.$aRecord->ri_name.'</h1></th>
    </tr>
    <tr>
        <td><img src="images/upload/'.$aRecord->ri_photos.'" /></td>
        <td>Contact: <strong>'.$aRecord->ri_contact.'</strong><br /><br />
        <strong style="color:red">BLOOD: </strong><span>'.$aRecord->ri_blood.'</span>
        </td>
        <td>
This Is Your Profile Page You can Also Visit Others Page to view: Comment, POST, Facebook Page View, Manage Your Contact info, Edit/Update you info and Also All other Super POST.
</td>
    </tr>
    <tr>
        <td>'.$aRecord->ri_adress.'</td>
        <td colspan="2"><strong>Email: </strong> <a href="#">'.$aRecord->ri_email.'</a></td>
    </tr>
</table>
</tr>';
}
echo '</table>
</fieldset>';
}
}
?>
