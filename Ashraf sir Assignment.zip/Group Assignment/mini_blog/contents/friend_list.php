<?php 
require_once ("includes/con_db.php");
/*+++++++++++++++++++++ FIND FRIEND ++++++++++++++++++++++++*/
if(@$_POST['findFrnd'] == "FIND"){
	$unqID = $_POST['FndFrndId'];
	/*++++++++++++++++++ FIND FRIEND BY UNIQUE ID++++++++++++++++++++++*/
	if(ctype_digit($unqID)){
	$sqlFndFrnd = "SELECT * FROM tbl_registration WHERE ri_id = '$unqID' AND ri_sts=1";
	$qryFndFrnd = @mysqli_query($con,$sqlFndFrnd) or die('Error in Query Error: '.mysqli_error($con));
	$cntUniqId = @mysqli_num_rows($qryFndFrnd) or die('Error in FIND BY ID Error: '.mysqli_error($con));
	}else{
	/*++++++++++++++++++ FIND FRIEND BY UNIQUE ID++++++++++++++++++++++*/
	$sqlFndFrnd2 = "SELECT * FROM tbl_registration WHERE ri_name LIKE '%$unqID%' AND ri_sts=1";
	$qryFndFrnd2 = @mysqli_query($con,$sqlFndFrnd2) or die('Error in Query Error: '.mysqli_error($con));
	$cntUniqId2 = @mysqli_num_rows($qryFndFrnd2) or die('Error in FIND by NAME Error: '.mysqli_error($con));
	}
	/*CHECK DUPLICATE FRINED*/
	$sqlChkDplctFrnd = "SELECT * FROM tbl_friend WHERE frnd_ri_id = '$unqID' AND ri_id = '$_SESSION[uId]'";
	$qryChkDplctFrnd = @mysqli_query($con,$sqlChkDplctFrnd) or die("Error in Insertion User: " . mysqli_error($con));
	$cntChkDplctFrnd = mysqli_num_rows($qryChkDplctFrnd);
}
?>
<div class="leftHalf">
<table align="left">
	<tr>
		<th colspan="2"><h2>FIND FRIENDS</h2> </th>
	</tr>
	<tr>
		<td>
<form method="POST" enctype="multipart/form-data" action="">
	<input type="text" name="FndFrndId" value="" placeholder="By Unique ID/Name" />
	<input type="submit" name="findFrnd" value="FIND" class="google-button" />
</form>
		</td>
	</tr>
</table>
<table>
	<?php if(@$cntUniqId>0){ 
		$frndListFind = mysqli_fetch_object($qryFndFrnd);	
	?>
	<tr style="background: #F7F7F7">
		<td style="width: 20%">
			<img width="80%" src="images/upload/<?php echo $frndListFind -> ri_photos; ?>" />
		</td>
		<td>
			<h3><?php echo $frndListFind->ri_name ?> [<?php echo $frndListFind->ri_id ?>]</h3>
			<?php echo $frndListFind->ri_gender ?><br />
			
<?php if($cntChkDplctFrnd == 0 && $frndListFind->ri_id != $_SESSION['uId']){ ?>			
<form method="POST" enctype="multipart/form-data" action="includes/actions/insert_action.php">
				<input type="hidden" name="adFrndId" value="<?php echo $frndListFind -> ri_id; ?>" />
				<input type="submit" name="addFrnd" value="ADD" class="google-button google-button-blue" />
</form>
<?php } ?>
		</td>
	</tr>
		<?php  }if(@$cntUniqId2 > 0){ 
		while($frndListFind2 = mysqli_fetch_object($qryFndFrnd2)){ 
		$sqlDplctNameChk = "SELECT tbl_registration.ri_id FROM tbl_registration,tbl_friend 
		WHERE tbl_registration.ri_id='$frndListFind2->ri_id' 
		AND tbl_friend.frnd_ri_id = tbl_registration.ri_id AND tbl_friend.ri_id='$_SESSION[uId]'";
		$qryDplctNameChk = @mysqli_query($con,$sqlDplctNameChk) or die('Error in Query Error: '.mysqli_error($con));
		$recDplctNameChk = mysqli_fetch_array($qryDplctNameChk);
		?>
	<tr style="background: #F7F7F7">
		<td style="width: 20%">
			<img width="80%" src="images/upload/<?php echo $frndListFind2 -> ri_photos; ?>" />
		</td>
		<td>
			<h3><?php echo $frndListFind2->ri_name ?> [<?php echo $frndListFind2->ri_id ?>]</h3>
			<?php echo $frndListFind2->ri_gender ?><br />
			
<?php if($cntChkDplctFrnd == 0 && $frndListFind2->ri_id != $_SESSION['uId'] && $recDplctNameChk['ri_id'] != $frndListFind2->ri_id){ 
?>			
<form method="POST" enctype="multipart/form-data" action="includes/actions/insert_action.php">
				<input type="hidden" name="adFrndId" value="<?php echo $frndListFind2 -> ri_id; ?>" />
				<input type="submit" name="addFrnd" value="ADD" class="button red" />
</form>
<?php } ?>
		</td>
	</tr>
<?php  }} ?>
</table>
</div>
<!--+++++++++++++++++++MY Frind SECTION++++++++++++++++++++++++-->
<div class="rightHalf">
<table align="right">
	<tr>
		<th colspan="2"><h2>MY FRIENDS</h2> </th>
	</tr>
	<?php 
	$numMyFrnd = mysqli_num_rows($qryMyfrnd);
	if($numMyFrnd > 0 ){
		$cols = 2; $cnt = 1;
		$new = $cols - ($numMyFrnd%$cols);
		while($frndListMy = mysqli_fetch_object($qryMyfrnd)) { 
			if($cnt % $cols == 1){
				echo "<tr style='background: #FFF4F4'>";
			}
	?>
		<td style="width: 20%">
			<img width="100%" src="images/upload/<?php echo $frndListMy -> ri_photos; ?>" />
		</td>
		<td>
			<h3><?php echo $frndListMy->ri_name ?> [<?php echo $frndListMy->ri_id ?>]</h3>
			<strong>(<?php echo $frndListMy->ri_adress ?>)</strong> <br />
			<strong>MOB: <?php echo $frndListMy->ri_contact ?></strong> <br />
			<strong style="text-decoration: underline; color: #0055CC"><?php echo $frndListMy->ri_email ?></strong> <br />
			<strong>BLOOD: <?php echo $frndListMy->ri_blood ?></strong> <br />
<form method="POST" enctype="multipart/form-data" action="includes/actions/edit_action.php">
	<input type="hidden" name="blckFrndId" value="<?php echo $frndListMy -> ri_id; ?>" />
	<?php
		if($frndListMy->frnd_sts == 'A'){ 
	?>
	<input type="submit" name="blockFrnd" value="OFF" class="button red" />
	<?php }else if($frndListMy->frnd_sts == 'B'){ ?>
	<input type="submit" name="unblkFrnd" value="ON" class="button green" />
	<?php } ?>
</form>
		</td>
	<?php  
		if($cnt % $cols == 0){
			echo "<tr />";
		}$cnt++;
	}
	}
	if(@$nbsp > 0) { // Add unused column in last row
	 for ($i = 0; $i < $new; $i++) {
	 	 echo '<td>&nbsp;</td>'; 
 	}
 		echo "</tr>";
 	}
	?>
	</table>
</div>