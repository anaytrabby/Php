<?php
$sqlPost = "SELECT * FROM tbl_user,tbl_registration,tbl_super_post 
			WHERE (tbl_registration.ri_id=tbl_super_post.ri_id AND 
			tbl_user.ui_ri=tbl_super_post.ri_id) ORDER BY ri_spr_time DESC LIMIT 4";
$postResultSet = @mysqli_query($con,$sqlPost) or die('Error in Query Error: ' . mysqli_error($con));
?>
<h2>All Post</h2>
<div id="response">
<table align="center" width="100%">
<?php
while($postRecord = mysqli_fetch_object($postResultSet)){	
	echo '<tr style="background-color:#e7ebf2;" align="center">
			<td><img class="radiusBorder" width="10%" src="images/upload/' . $postRecord -> ri_photos . '" /><br />' . $postRecord -> ri_spr_post . '<br />';
	if (@$_SESSION[logiName] != "" && ($postRecord -> ri_id == @$_SESSION[uId])) {
		echo '<a style="color:#019400;" href="includes/actions/delete_action.php?page=myPost&postId=' . $postRecord -> spr_post_id . '&usrPstId=' . $postRecord -> ri_id . '">delete</a> ';
	}
	echo '<em style="color:#bf0000; font-size: 11px">[ ' . $postRecord -> ri_spr_time . ' ]
		</em></td>
		</tr>
		';
}
echo '</table>';
?>
</div>
     <input type="hidden" id="pageno" value="1">
     <img id="loader" src="loader.gif">
     <script>
         $(document).ready(function(){
             $('#loader').on('inview', function(event, isInView) {
                 if (isInView) {
                     var nextPage = parseInt($('#pageno').val())+1;
                     $.ajax({
                         type: 'POST',
                         url: 'includes/helpers/pagination.php',
                         data: { pageno: nextPage },
                         success: function(data){
                             $('#response').append(data);
                             $('#pageno').val(nextPage);
                         }
                     });
                 }
             });
         });
     </script>

