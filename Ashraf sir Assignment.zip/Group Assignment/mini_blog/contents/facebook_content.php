<table>
	<tr>
		<td>
<div class="fb-like-box" data-href="https://www.facebook.com/profile.php" data-width="450" data-height="380" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="true" data-show-border="false"></div>
		</td>
	</tr>
</table>